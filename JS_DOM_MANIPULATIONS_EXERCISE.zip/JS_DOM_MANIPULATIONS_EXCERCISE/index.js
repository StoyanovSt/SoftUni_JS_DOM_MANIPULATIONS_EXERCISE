const elements = {
    addButton: () => document.querySelector('.form-control > button'),
    lectureName: () => document.querySelectorAll('.form-control').item(0).children[1],
    date: () => document.querySelectorAll('.form-control').item(1).children[1],
    module: () => document.querySelectorAll('.form-control').item(2).children[1],
    trainingsSection: () => document.querySelector('.modules'),
}

function solve() {
    // add event listener
    elements.addButton().addEventListener('click', (e) => {
        e.preventDefault();

        const lectureName = elements.lectureName().value;
        let date = elements.date().value;
        const lectureModule = elements.module().value;

        // validate inputs
        if (lectureName === '') {
            return;
        }

        if (date === '') {
            return;
        }

        if (lectureModule === 'Select module') {
            return;
        }

        // cast to date type
        date = new Date(date);

        // search if such module already exists
        let moduleAlreadyExists = false;

        Array.from(elements.trainingsSection().children).forEach(el => {
            if (el.children[0].textContent.startsWith(`${lectureModule.toUpperCase()}`)) {
                el.children[1].appendChild(addLectureToExistingModule(lectureName, date));
                moduleAlreadyExists = true;
            }

        });

        // conditional lecture adding
        if (!moduleAlreadyExists) {
            elements.trainingsSection().appendChild(addLectureElement(lectureName, date, lectureModule));
        }

    });

};

const addLectureElement = (lectureName, date, lectureModule) => {
    const divEl = document.createElement('div');
    divEl.setAttribute('class', 'module');

    const h3 = document.createElement('h3');
    h3.textContent = `${lectureModule.toUpperCase()}-MODULE`;

    const ul = document.createElement('ul');

    const liEl = document.createElement('li');
    liEl.setAttribute('class', 'flex');

    const h4 = document.createElement('h4');
    h4.textContent = `${lectureName} - ${date.getFullYear()}/${(date.getMonth() + 1) < 10 ?
        '0'.concat(date.getMonth() + 1) :
        date.getMonth() + 1
        }/${date.getDate() < 10 ?
            '0'.concat(date.getDate()) :
            date.getDate()
        } - ${date.getHours() < 10 ?
            '0'.concat(date.getHours()) :
            date.getHours()
        }:${date.getMinutes() < 10 ?
            '0'.concat(date.getMinutes()) :
            date.getMinutes()
        }`;

    const buttonEl = document.createElement('button');
    buttonEl.setAttribute('class', 'red');
    buttonEl.textContent = 'Del';

    // add event listener to the button
    buttonEl.addEventListener('click', (e) => {
        if (ul.children.length > 1) {
            liEl.remove();
        } else {
            divEl.remove();
        }
        
    });

    // append child elements to parent elements
    liEl.appendChild(h4);
    liEl.appendChild(buttonEl);

    ul.appendChild(liEl);

    divEl.appendChild(h3);
    divEl.appendChild(ul);

    return divEl;
}

const addLectureToExistingModule = (lectureName, date) => {
    const liEl = document.createElement('li');
    liEl.setAttribute('class', 'flex');

    const h4 = document.createElement('h4');
    h4.textContent = `${lectureName} - ${date.getFullYear()}/${(date.getMonth() + 1) < 10 ?
        '0'.concat(date.getMonth() + 1) :
        date.getMonth() + 1
        }/${date.getDate() < 10 ?
            '0'.concat(date.getDate()) :
            date.getDate()
        } - ${date.getHours() < 10 ?
            '0'.concat(date.getHours()) :
            date.getHours()
        }:${date.getMinutes() < 10 ?
            '0'.concat(date.getMinutes()) :
            date.getMinutes()
        }`;

    const buttonEl = document.createElement('button');
    buttonEl.setAttribute('class', 'red');
    buttonEl.textContent = 'Del';

    // add event listener to the button
    buttonEl.addEventListener('click', (e) => {
        if (liEl.parentElement.children.length > 1) {
            liEl.remove();
        } else {
            liEl.parentElement.parentElement.remove();
        }

    });

    // append child elements to parent elements
    liEl.appendChild(h4);
    liEl.appendChild(buttonEl);

    return liEl;
}